package com.moe.demo.blesensor;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.res.ColorStateList;
import android.os.Environment;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.regex.Pattern;

public class HelperClass {

    AlertDialog alertDialog;
    Activity activity;


    HelperClass(Activity act) {
        activity = act;
    }
    public void showLoader(final String title, final String message) {
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {

                if(alertDialog != null && alertDialog.isShowing() ) {
                    alertDialog.cancel();
                    alertDialog.dismiss();
                }

                Log.d("ShowingLoader", "Showing loader method");

                LayoutInflater inflater = activity.getLayoutInflater();
                View customLayout = inflater.inflate(R.layout.custom_alert, null);
                ProgressBar progressBar = customLayout.findViewById(R.id.progressBar);
                progressBar.setProgressTintList(ColorStateList.valueOf(activity.getResources().getColor(R.color.white)));
                // Set the indeterminate tint color programmatically
                progressBar.setIndeterminateTintList(ColorStateList.valueOf(activity.getResources().getColor(R.color.white)));


                int customBackgroundColor = activity.getResources().getColor(R.color.darkTheme);

                AlertDialog.Builder builder = new AlertDialog.Builder(activity,R.style.CustomAlertDialogStyle);
                builder.setView(customLayout);

                alertDialog = builder.create();
                //alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(customBackgroundColor));

                alertDialog.setTitle(title);

                SpannableString spannableMessage = new SpannableString(message);
                spannableMessage.setSpan(new ForegroundColorSpan(activity.getResources().getColor(R.color.white)), 0, spannableMessage.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);


                alertDialog.setMessage(spannableMessage);
                alertDialog.setCancelable(false);  // Set to true if you want the dialog to be cancellable

                alertDialog.show();
            }
        });
    }

    public void updateLoader(final String message) {
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if(alertDialog != null && alertDialog.isShowing() ) {
                    SpannableString spannableMessage = new SpannableString(message);
                    spannableMessage.setSpan(new ForegroundColorSpan(activity.getResources().getColor(R.color.white)), 0, spannableMessage.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                    alertDialog.setMessage(spannableMessage);
                }
            }
        });
    }

    public void closeLoader() {
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if(alertDialog != null && alertDialog.isShowing() ) {
                    alertDialog.cancel();
                    alertDialog.dismiss();
                }
            }
        });
    }
}
