package com.moe.demo.blesensor;

import androidx.appcompat.app.AppCompatActivity;

import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.content.Context;
import android.content.Intent;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import com.moe.demo.blesensor.R;
import com.opencsv.CSVWriter;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class RemoteActivity extends AppCompatActivity implements BluetoothGattCallbackListener{
    static private final String TAG = "RemoteActivity";
    private BluetoothGatt gatt;
    BluetoothGattSingleton bluetoothGattSingleton;
    private static final UUID BLE_SERVICE_UUID = UUID.fromString("BA3FC78E-12AD-4CC6-8EE2-4FFC42F0757D");
    private static final UUID PULSE_BLE_CHARACTERISTIC_UUID = UUID.fromString("D3C40F85-0ADA-4072-A155-FC78CE198193");
    FileWriter writer;
    CSVWriter csvWriter;
    RemoteActivity thisActivity;
    Button BtnStop;
    boolean saveStopped = false;
    HelperClass utils;

    public class DataPoint {
        private float pulse;
        private float spo2;
        private float gmr;
        private float temp;
        private int healthy; // 0 or 1

        void setPulse(float data) {
            pulse = data;
        }
        void setSpo2(float data) {
            spo2 = data;
        }
        void setGmr(float data) {
            gmr = data;
        }
        void setTemp(float data) {
            temp = data;
        }
        void setHealthy(int data) {
            healthy = data;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_remote);
        thisActivity = this;
        utils = new HelperClass(thisActivity);

        bluetoothGattSingleton = BluetoothGattSingleton.getInstance();
        bluetoothGattSingleton.registerCallbackListener(this);

        gatt = bluetoothGattSingleton.getBluetoothGatt();

        if (gatt != null) {
            enableNotification(gatt, PULSE_BLE_CHARACTERISTIC_UUID);
        } else {
            // handle error: BluetoothGatt object is null
        }

        BtnStop = findViewById(R.id.saveButton);

        BtnStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(saveStopped == false) {
                    saveStopped = true;
                    File filesDir = getFilesDir();
                    File file = new File(filesDir, "data.csv");
                    copyFileToDownloads(thisActivity, file.getAbsolutePath());
                    BtnStop.setText("Start Recording");
                } else {
                    saveStopped = false;
                    BtnStop.setText("Stop Recording and Copy to Downloads");
                }
            }
        });
    }

    private void enableNotification(final BluetoothGatt gatt, UUID characteristicUUID) {
        BluetoothGattCharacteristic characteristic = gatt.getService(BLE_SERVICE_UUID).getCharacteristic(characteristicUUID);
        if (characteristic != null) {
            gatt.setCharacteristicNotification(characteristic, true);
            BluetoothGattDescriptor descriptor = characteristic.getDescriptor(
                    UUID.fromString("00002902-0000-1000-8000-00805f9b34fb"));
            if (descriptor != null) {
                descriptor.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                gatt.writeDescriptor(descriptor);
            } else {
                Log.e(TAG, "Descriptor is null for characteristic: " + characteristicUUID.toString());
            }
        } else {
            Log.e(TAG, "Characteristic is null for UUID: " + characteristicUUID.toString());
        }
    }

    @Override
    public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {

    }

    @Override
    public void onServicesDiscovered(BluetoothGatt gatt, int status) {

    }

    @Override
    public void onCharacteristicWrite(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {

    }

    @Override
    public void onCharacteristicRead(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {

    }

    @Override
    public void onCharacteristicChanged(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
        if(saveStopped) {
            Log.d(TAG, "onCharacteristicChanged: saveStopped");
        } else {

            UUID characteristicUUID = characteristic.getUuid();
            byte[] value = characteristic.getValue();
            if (characteristicUUID.equals(PULSE_BLE_CHARACTERISTIC_UUID)) {
                String[] data = new String(value).split(":");
                int pulse = Integer.parseInt(data[0]);
                int spo2 = Integer.parseInt(data[1]);
                int gsr = Integer.parseInt(data[2]);
                int temp = Integer.parseInt(data[3]);
                try {
                    writeToCSV(data[0], data[1], data[2], data[3]);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }

    public void onBackPressed() {
        bluetoothGattSingleton.getBluetoothGatt().disconnect();

        Intent intent = new Intent(RemoteActivity.this, landingActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        finish();
    }

    public void copyFileToDownloads(Context context, String sourceFilePath) {
        File sourceFile = new File(sourceFilePath);
        String fileName = sourceFile.getName();
        File to = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS) +  "/" + fileName);
        if(to.exists()){
            to.delete();
        }

        copyDbToExternalStorage(to,sourceFile);
        // Trigger a media scan for the new file
        MediaScannerConnection.scanFile(context, new String[]{to.getAbsolutePath()}, null,
                new MediaScannerConnection.OnScanCompletedListener() {
                    @Override
                    public void onScanCompleted(String path, Uri uri) {
                    }
                });
    }

    public void copyDbToExternalStorage(File toFile , File fromFile){
        try {
            toFile.createNewFile();
            InputStream inputStream = null;
            OutputStream outputStream = null;
            inputStream = new FileInputStream(fromFile);
            outputStream = new FileOutputStream(toFile);
            byte[] buffer = new byte[1024];
            int read;
            while ((read = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, read);
            }
            inputStream.close();
            outputStream.flush();
            outputStream.close();
        }
        catch (Exception e) {
            Log.e("Exception" , e.toString());
        }
    }


    public void writeToCSV(String pulse, String spo2, String gmr, String temp) throws IOException {

        File filesDir = getFilesDir();
        File file = new File(filesDir, "data.csv");
        try {
            // create FileWriter object with file as parameter
            FileWriter outputfile = new FileWriter(file,true);

            // create CSVWriter object filewriter object as parameter
            CSVWriter writer = new CSVWriter(outputfile);

            // Write the data row
            String[] data = {pulse, spo2, gmr, temp};
            writer.writeNext(data);

            // closing writer connection
            writer.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            if (csvWriter != null) {
                // Close the CSVWriter and FileWriter objects
                csvWriter.close();
            }
            if (writer != null) {
                writer.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

