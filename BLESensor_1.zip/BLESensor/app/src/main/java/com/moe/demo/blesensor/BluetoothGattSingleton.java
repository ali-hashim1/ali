package com.moe.demo.blesensor;

import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.content.Context;
import android.os.Build;
import android.util.Log;

import java.nio.charset.StandardCharsets;
import java.util.UUID;

public class BluetoothGattSingleton {
    private static final String TAG = "BluetoothGattSingleton";
    private static BluetoothGattSingleton instance;
    private BluetoothGatt bluetoothGatt;
    private BluetoothGattCallbackListener callbackListeners;
    BluetoothDevice bluetoothDevice;

    Context context;

    private BluetoothGattSingleton() {}

    public void registerCallbackListener(BluetoothGattCallbackListener listener) {
        callbackListeners = listener;
    }

    public static synchronized BluetoothGattSingleton getInstance() {
        if (instance == null) {
            instance = new BluetoothGattSingleton();
        }
        return instance;
    }

    public void setBluetoothGatt(BluetoothGatt bluetoothGatt) {
        this.bluetoothGatt = bluetoothGatt;
    }

    public void connect(Context Context, BluetoothDevice device) {
        bluetoothDevice = device;
        context = Context;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            bluetoothGatt = bluetoothDevice.connectGatt(context, false, gattCallback, BluetoothDevice.TRANSPORT_LE);
        } else {
            bluetoothGatt = bluetoothDevice.connectGatt(context, false, gattCallback);
        }
    }

    public BluetoothGatt getBluetoothGatt() {
        return this.bluetoothGatt;
    }

    private BluetoothGattCallback gattCallback = new BluetoothGattCallback() {

        @Override
        public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
            Log.d(TAG, "onConnectionStateChange, New state : " + newState + ", Status : " + status);
            super.onConnectionStateChange(gatt, status, newState);
            callbackListeners.onConnectionStateChange(gatt,status,newState);
        }

        @Override
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            Log.d(TAG, "onServicesDiscovered, Status : " + status);
            super.onServicesDiscovered(gatt, status);
            callbackListeners.onServicesDiscovered(gatt,status);
        }

        @Override
        public void onCharacteristicWrite(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {

            callbackListeners.onCharacteristicWrite(gatt,characteristic,status);
        }

        @Override
        public void onMtuChanged(BluetoothGatt gatt, int mtu, int status) {
            super.onMtuChanged(gatt, mtu, status);
        }

        @Override
        public void onCharacteristicRead(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
            byte[] responseData = characteristic.getValue();
            if (status == BluetoothGatt.GATT_SUCCESS) {
                callbackListeners.onCharacteristicRead(gatt,characteristic,status);
            }
        }

        public void onCharacteristicChanged(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
            byte[] responseData = characteristic.getValue();
            callbackListeners.onCharacteristicChanged(gatt, characteristic);
        }
    };
}