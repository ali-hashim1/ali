package com.moe.demo.blesensor;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanFilter;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.moe.demo.blesensor.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends AppCompatActivity implements BluetoothGattCallbackListener {

    private static final String TAG = "MainActivity";
    private static final int REQUEST_ENABLE_BT = 1;
    private ListView listView;
    private TextView NoConnectedDevice;
    private ArrayList<BluetoothDevice> devices = new ArrayList<>();
    private ArrayList<String> Uuid = new ArrayList<>();
    private ArrayAdapter<String> adapter;
    MainActivity context;
    private BluetoothAdapter bleAdapter;
    private BluetoothGatt bluetoothGatt;
    private BluetoothGattService service;
    private String currentUuid;
    private BluetoothDevice currentDevice;
    private ArrayList<String> charUuidList = new ArrayList<>();

    private HashMap<String, String> uuidMap = new HashMap<>();
    private boolean isReadingDescriptors = false;
    BluetoothGattSingleton bluetoothGattSingleton;
    HelperClass utils;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        context = this;
        utils = new HelperClass(context);

        listView = findViewById(R.id.listViewDevices);
        NoConnectedDevice = findViewById((R.id.text_view));
        adapter = new ArrayAdapter<>(this, R.layout.custom_list_item, R.id.textView);
        listView.setAdapter(adapter);

        final BluetoothManager bluetoothManager = (BluetoothManager) context.getSystemService(Context.BLUETOOTH_SERVICE);
        bleAdapter = bluetoothManager.getAdapter();

        bluetoothGattSingleton = BluetoothGattSingleton.getInstance();
        bluetoothGattSingleton.registerCallbackListener(this);

        Button scanButton = findViewById(R.id.buttonScanAgain);
        scanButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                scanForPeripherals();
            }
        });

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                BluetoothDevice device = devices.get(position);

                connect(device);
            }
        });
        scanForPeripherals();
    }

    public void connect(BluetoothDevice bluetoothDevice) {
        utils.showLoader("Please Wait", "Connecting ...");
        currentDevice = bluetoothDevice;
        bluetoothGattSingleton.connect(context,currentDevice);
    }

    private void scanForPeripherals() {

        if (!this.hasPermissions()) {

        } else {
            final BluetoothLeScanner scanner = bleAdapter.getBluetoothLeScanner();
            List<ScanFilter> filters = new ArrayList<>();
            ScanSettings settings = new ScanSettings.Builder()
                    .setScanMode(ScanSettings.SCAN_MODE_LOW_POWER)
                    .build();

            final ScanCallback scanCallback = new ScanCallback() {
                @Override
                public void onScanResult(int callbackType, ScanResult result) {
                    BluetoothDevice device = result.getDevice();
                    String deviceName = device.getName();

                    boolean deviceExists = false;
                    String serviceUuid = "";

                    if (result.getScanRecord().getServiceUuids() != null && result.getScanRecord().getServiceUuids().size() > 0) {
                        serviceUuid = result.getScanRecord().getServiceUuids().get(0).toString();
                    }
                    Log.d("SACInstructionActivity", "Add service UUID : " + serviceUuid);

                    if (devices.contains(device)) {
                        deviceExists = true;
                    }
                    Log.e("SACInstructionActivity", "Device exist : " + deviceExists);

                    Log.d("Ble", "Got scan result : " + deviceName);
                    if (!deviceExists && deviceName != null && deviceName.startsWith("PDM")) {
                        Log.d("Ble", "Got scan result : " + deviceName);
                        devices.add(device);
                        Uuid.add(serviceUuid);
                        adapter.add(deviceName);
                        adapter.notifyDataSetChanged();
                        NoConnectedDevice.setVisibility(View.GONE);
                        utils.closeLoader();
                    }
                }

                @Override
                public void onBatchScanResults(List<ScanResult> results) {
                    super.onBatchScanResults(results);
                }

                @Override
                public void onScanFailed(int errorCode) {
                    super.onScanFailed(errorCode);
                }
            };
            utils.showLoader("Please Wait", "Scanning ...");
            scanner.startScan(filters, settings, scanCallback);
            Handler someHandler = new Handler();
            someHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    utils.closeLoader();
                    scanner.stopScan(scanCallback);
                }
            }, 10000);
        }
    }

    private boolean hasPermissions() {
        if (bleAdapter == null || !bleAdapter.isEnabled()) {
            requestBluetoothEnable();
            return false;
        } else if (!hasLocationPermissions()) {
            requestLocationPermission();
            return false;
        }
        return true;
    }

    private void requestBluetoothEnable() {
        Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
        context.startActivityForResult(enableBtIntent, 1);
    }

    private boolean hasLocationPermissions() {
        return ContextCompat.checkSelfPermission(context,
                Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestLocationPermission() {
        ActivityCompat.requestPermissions(context,
                new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 102);
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_ENABLE_BT) {
            if (resultCode == RESULT_OK) {
                // Bluetooth was turned on successfully.
                Log.d(TAG, "bt enabled");
                scanForPeripherals();
            } else {
                // User canceled or there was an error turning on Bluetooth.
                Log.d(TAG, "bt disabled");
                onBackPressed();
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
        Log.d(TAG, "onConnectionStateChange, New state : " + newState + ", Status : " + status);
        if (status == BluetoothGatt.GATT_FAILURE) {
            utils.closeLoader();
            return;
        } else if (status != BluetoothGatt.GATT_SUCCESS) {
            utils.closeLoader();
            return;
        }
        if (newState == BluetoothProfile.STATE_CONNECTED) {
            Log.e(TAG, "Connected to GATT server.");
            gatt.discoverServices();
        } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
            Log.e(TAG, "Disconnected from GATT server.");
        }
    }

    @Override
    public void onServicesDiscovered(BluetoothGatt gatt, int status) {
        Log.d(TAG, "onServicesDiscovered, Status : " + status);
        if (status != BluetoothGatt.GATT_SUCCESS) {
            Log.d(TAG, "Status not success");
            utils.closeLoader();
            return;
        }

        utils.closeLoader();
        Intent intent = new Intent(MainActivity.this, RemoteActivity.class);
        startActivity(intent);
    }

    @Override
    public void onCharacteristicWrite(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {

    }

    @Override
    public void onCharacteristicRead(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {

    }

    @Override
    public void onCharacteristicChanged(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
    }
}